﻿using System;
using System.IO;
using System.Threading;
using System.Threading.Tasks;
using PassengerLib;

namespace _053502_Kravchenko_lab11_t2
{
    class Program
    {
        static async Task Main(string[] args)
        {
            Console.Clear();
            Console.WriteLine("########################################\n" +
                              "Program is start. Thread: " + Thread.CurrentThread.ManagedThreadId +
                              "\n########################################");
            StreamService streamService = new StreamService();

            using (MemoryStream memoryStream = new MemoryStream())
            {
                var t1 = streamService.WriteToStream(memoryStream);
                Console.WriteLine("----->");
                var t2 = streamService.CopyFromStream(memoryStream, "passengers.txt");

                await Task.WhenAll(new Task[] { t1, t2 });
            }

            Console.WriteLine("Number of passengers with baggage: " +
                              streamService.GetStatisticsAsync("passengers.txt", passenger => passenger.BaggageCount > 0).Result +
                              "\n########################################");
            string a = Console.ReadLine();
        }
    }
}